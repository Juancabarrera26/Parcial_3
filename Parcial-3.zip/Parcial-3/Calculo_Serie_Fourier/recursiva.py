def recursiva(f, t0, T, N, M, integrar):
    a = calcular_a(f, t0, T, N, M, integrar)
    b = calcular_b(f, t0, T, N, M, integrar)
    return a, b

def calcular_a(f, t0, T, n, M, integrar):
    if n == 0:
        return []
    anteriores = calcular_a(f, t0, T, n - 1, M, integrar)

    def funcion_coseno(t):
        return f(t) * cos(2 * 3.1416 * n * t / T)

    an = (2 / T) * integrar(funcion_coseno, t0, t0 + T, M)
    return anteriores + [an]

def calcular_b(f, t0, T, n, M, integrar):
    if n == 0:
        return []
    anteriores = calcular_b(f, t0, T, n - 1, M, integrar)

    def funcion_seno(t):
        return f(t) * sin(2 * 3.1416 * n * t / T)

    bn = (2 / T) * integrar(funcion_seno, t0, t0 + T, M)
    return anteriores + [bn]

def sin(x):
    return x - (x**3)/6 + (x**5)/120 - (x**7)/5040 + (x**9)/362880

def cos(x):
    return 1 - (x**2)/2 + (x**4)/24 - (x**6)/720 + (x**8)/40320
