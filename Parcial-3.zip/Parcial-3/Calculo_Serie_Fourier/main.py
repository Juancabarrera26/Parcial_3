import time
import iterativa
import recursiva

def f(t):
    return seno(2 * 3.1416 * t)

def seno(x):
    return taylor_sin(x)

def coseno(x):
    return taylor_cos(x)

def integrar(funcion, a, b, M):
    h = (b - a) / (M - 1)
    suma = funcion(a) + funcion(b)
    for i in range(1, M - 1):
        t = a + i * h
        suma += 2 * funcion(t)
    return (h / 2) * suma

def taylor_sin(x):
    return x - (x**3)/6 + (x**5)/120 - (x**7)/5040 + (x**9)/362880

def taylor_cos(x):
    return 1 - (x**2)/2 + (x**4)/24 - (x**6)/720 + (x**8)/40320

def comparar(f, t0, T, N, M):
    inicio1 = time.time()
    a1, b1 = iterativa.calcular_serie_iterativa(f, t0, T, N, M, integrar)
    tiempo1 = time.time() - inicio1

    inicio2 = time.time()
    a2, b2 = recursiva.recursiva(f, t0, T, N, M, integrar)
    tiempo2 = time.time() - inicio2

    print("Tiempo iterativo:", round(tiempo1, 6), "segundos")
    print("Tiempo recursivo:", round(tiempo2, 6), "segundos")

# Ejecución
t0 = 0
T = 2 * 3.1416
N = 10
M = 1000
comparar(f, t0, T, N, M)
