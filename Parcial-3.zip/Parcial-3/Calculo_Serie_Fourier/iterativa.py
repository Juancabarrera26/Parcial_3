def calcular_serie_iterativa(f, t0, T, N, M, integrar):
    a = []
    b = []

    for n in range(1, N + 1):
        def funcion_coseno(t):
            return f(t) * cos(2 * 3.1416 * n * t / T)

        def funcion_seno(t):
            return f(t) * sin(2 * 3.1416 * n * t / T)

        an = (2 / T) * integrar(funcion_coseno, t0, t0 + T, M)
        bn = (2 / T) * integrar(funcion_seno, t0, t0 + T, M)

        a.append(an)
        b.append(bn)

    return a, b

def sin(x):
    return x - (x**3)/6 + (x**5)/120 - (x**7)/5040 + (x**9)/362880

def cos(x):
    return 1 - (x**2)/2 + (x**4)/24 - (x**6)/720 + (x**8)/40320
